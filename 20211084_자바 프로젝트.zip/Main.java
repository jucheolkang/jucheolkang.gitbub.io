package org.javaro.lecture;

public class Main {
    public static void main(String[] args) {
        MemberJoinDAO memberJoinDAO = new MemberJoinDAO();
        memberJoinDAO.run();
    }
}
