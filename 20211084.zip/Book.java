package org.javaro.lecture;

public class Book {
    private String title; private String author; private Student student;
    public Book(String title){this.title = title;}

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Student getStudent() {
        return student;
    }

    public void setStudent(Student student) {
        this.student = student;
    }
    public String toString(){
        String available;
        if(this.getStudent() == null){
            available = "대출가능";
        }
        else{available = "대출자"+ this.getStudent().getName();}
        return "제목="+this.getTitle()+",저자=" + this.getAuthor()+","+available;

    }
}
