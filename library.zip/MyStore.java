package org.javaro.lecture;

public class MyStore {
    public static void main(String[] args){
        BookStore myStore = new BookStore("지산도서관");
        Book book1 = new Book("춘향전");
        Book book2 = new Book("홍길동전");
        Book book3 = new Book("심천전");
        Book book4 = new Book("전쟁과평화");
        Book book5 = new Book("논어");


        //book1.setAuthor("허균"); book2.setAuthor("미상");
        Student stud1 = new Student();
        Student stud2 = new Student();
        Student stud3 = new Student();
        Student stud4 = new Student();

        stud1.setName("홍길동"); stud2.setName("성춘향");
        stud3.setName("변학도"); stud4.setName("이몽룡");

        myStore.addBook(book1); myStore.addBook(book2);
        myStore.addBook(book3); myStore.addBook(book4);
        myStore.addBook(book5);

        myStore.addStudent(stud1);myStore.addStudent(stud2);
        myStore.addStudent(stud3);myStore.addStudent(stud4);

        System.out.println("지산도서관 도서관리 시스템 생성\n");
        myStore.printStatus();

        System.out.println("\n춘향전을 홍길동이 대출");
        myStore.checkOut(book1,stud1);
        myStore.printStatus();

        System.out.println("\n심청전을 홍길동이 대출");
        myStore.checkOut(book3,stud1);
        myStore.printStatus();

        System.out.println("\n심청전 반납");
        myStore.checkIn(book3);

        System.out.println("\n심청전을 변학도가 대출");
        myStore.checkOut(book3,stud3);
        myStore.printStatus();

        System.out.println("\n전쟁과평화를 성춘향이 대출");
        myStore.checkOut(book4,stud2);
        myStore.printStatus();

        System.out.println("\n논어를 변학도가 대출");
        myStore.checkOut(book5,stud3);
        myStore.printStatus();

        System.out.println("\n전쟁과평화 반납");
        myStore.checkIn(book1);

       /* System.out.println("book2 심청전을 stud1 이몽룡에게 대출");
        myStore.checkOut(book2,stud1);*/

        myStore.printStatus();
    }
}
